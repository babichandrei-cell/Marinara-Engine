const PACKAGE_ID = "character-lore-sync";
const STATE_KIND = "chat-state";
const STATE_VERSION = 1;

const warnedMissingTarget = new Set();

function nowIso() {
  return new Date().toISOString();
}

function isRecord(value) {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

function asRecord(value) {
  return isRecord(value) ? value : {};
}

function boolish(value) {
  return value === true || value === "true";
}

function normalizeState(document) {
  const data = asRecord(document?.data);
  const rawEntries = asRecord(data.outfitEntries);
  const outfitEntries = {};

  for (const [characterId, value] of Object.entries(rawEntries)) {
    const item = asRecord(value);
    if (typeof item.entryId !== "string" || !item.entryId.trim()) continue;
    outfitEntries[characterId] = {
      entryId: item.entryId.trim(),
      characterName:
        typeof item.characterName === "string" && item.characterName.trim()
          ? item.characterName.trim()
          : characterId,
    };
  }

  return {
    version: STATE_VERSION,
    enabled: data.enabled !== false,
    targetLorebookId:
      typeof data.targetLorebookId === "string" && data.targetLorebookId.trim()
        ? data.targetLorebookId.trim()
        : null,
    outfitEntries,
  };
}

function parseLorebookData(book) {
  return asRecord(book?.data);
}

function lorebookName(book) {
  const data = parseLorebookData(book);
  return typeof data.name === "string" && data.name.trim()
    ? data.name.trim()
    : book?.id ?? "Unknown lorebook";
}

function lorebookIsEnabled(book) {
  const data = parseLorebookData(book);
  return boolish(data.enabled);
}

function lorebookChatId(book) {
  const data = parseLorebookData(book);
  return typeof data.chatId === "string" && data.chatId.trim()
    ? data.chatId.trim()
    : null;
}

function parseChatMetadata(value) {
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value);
      return isRecord(parsed) ? parsed : {};
    } catch {
      return {};
    }
  }
  return isRecord(value) ? value : {};
}

function readStringArray(value) {
  return Array.isArray(value)
    ? value.filter((item) => typeof item === "string" && item.trim()).map((item) => item.trim())
    : [];
}

async function resolveTargetLorebook(resources, chat, state) {
  const books = await resources.listLorebooks();
  const byId = new Map(books.map((book) => [book.id, book]));
  const metadata = parseChatMetadata(chat.metadata);
  const activeLorebookIds = readStringArray(metadata.activeLorebookIds).filter((id) => byId.has(id));

  // Explicitly pinned chat lorebooks are authoritative write targets.
  // Auto-activated Character/Persona/Global lorebooks are intentionally ignored.
  if (activeLorebookIds.length === 1) {
    const id = activeLorebookIds[0];
    return {
      id,
      name: lorebookName(byId.get(id)),
      inferred: false,
    };
  }

  // Preserve an already-known target only when the chat currently exposes no
  // explicit pinned lorebook. Never use it to override an ambiguous selection.
  if (activeLorebookIds.length === 0 && state.targetLorebookId && byId.has(state.targetLorebookId)) {
    return {
      id: state.targetLorebookId,
      name: lorebookName(byId.get(state.targetLorebookId)),
      inferred: true,
    };
  }

  return null;
}

function entryName(characterName) {
  return `${characterName} - Current Outfit`;
}

function entryContent(characterName, outfit) {
  return `${characterName}'s current outfit: ${outfit}`;
}

async function entryExists(resources, entryId) {
  try {
    const rows = await resources.listEligibleLorebookEntries({
      lorebookIds: [],
      entryIds: [entryId],
    });
    return rows.some((row) => row.id === entryId);
  } catch {
    return false;
  }
}

async function loadState(persistence, chatId) {
  const document = await persistence.documents.getById(PACKAGE_ID, chatId);
  return {
    document,
    state: normalizeState(document),
  };
}

async function saveState(persistence, chat, document, state) {
  const timestamp = nowIso();
  const data = {
    version: STATE_VERSION,
    enabled: state.enabled,
    targetLorebookId: state.targetLorebookId,
    outfitEntries: state.outfitEntries,
  };

  if (!document) {
    return persistence.documents.create({
      id: chat.id,
      packageId: PACKAGE_ID,
      kind: STATE_KIND,
      name: `Character Lore Sync — ${chat.name || chat.id}`,
      description: "Per-chat Character Lore Sync configuration and managed Lore entry identities.",
      data,
      createdAt: timestamp,
      updatedAt: timestamp,
    });
  }

  return persistence.documents.update({
    id: document.id,
    packageId: PACKAGE_ID,
    expectedRevision: document.revision,
    name: document.name,
    description: document.description,
    data,
    updatedAt: timestamp,
  });
}

async function syncCharacter({
  resources,
  targetLorebookId,
  character,
  mapping,
}) {
  const characterName =
    typeof character.name === "string" && character.name.trim()
      ? character.name.trim()
      : character.characterId;
  const outfit =
    typeof character.outfit === "string" ? character.outfit.trim() : "";

  if (!character.characterId || !characterName || !outfit) return false;

  const content = entryContent(characterName, outfit);
  const name = entryName(characterName);
  const keys = [characterName];

  const existing = mapping[character.characterId];
  if (existing?.entryId && (await entryExists(resources, existing.entryId))) {
    await resources.updateLorebookEntry(existing.entryId, {
      name,
      content,
      description: "Managed automatically by Character Lore Sync.",
      keys,
      secondaryKeys: [],
    });
    mapping[character.characterId] = {
      entryId: existing.entryId,
      characterName,
    };
    return true;
  }

  const created = await resources.createLorebookEntry(targetLorebookId, {
    name,
    content,
    description: "Managed automatically by Character Lore Sync.",
    keys,
    secondaryKeys: [],
    enabled: true,
    constant: false,
    selective: false,
    matchWholeWords: false,
    preventRecursion: true,
    excludeRecursion: true,
    excludeFromVectorization: true,
  });

  mapping[character.characterId] = {
    entryId: created.id,
    characterName,
  };
  return true;
}

export async function activate(context) {
  const runtime = context?.api?.runtime;
  const persistence = runtime?.persistence;
  const resources = runtime?.resources;
  const logger = runtime?.logger;

  if (!runtime || !persistence || !resources) {
    throw new Error("Character Lore Sync requires the server runtime persistence and resource hosts.");
  }
  if (typeof context.api.registerAgentPipelineSettledHandler !== "function") {
    throw new Error("Character Lore Sync requires Capability API 1.14 lifecycle support.");
  }
  if (typeof persistence.getCharacterTrackerState !== "function") {
    throw new Error("Character Lore Sync requires Capability API 1.14 Character Tracker reads.");
  }
  if (
    typeof resources.createLorebookEntry !== "function" ||
    typeof resources.updateLorebookEntry !== "function"
  ) {
    throw new Error("Character Lore Sync requires Capability API 1.14 Lore entry writes.");
  }

  logger?.info?.("[character-lore-sync] activated");

  return context.api.registerAgentPipelineSettledHandler(
    async ({ chatId, messageId, swipeIndex }) => {
      await persistence.withChatLock(chatId, async () => {
        const chat = await persistence.getChat(chatId);
        if (!chat) return;

        const { document, state } = await loadState(persistence, chatId);
        if (!state.enabled) return;

        const characters = await persistence.getCharacterTrackerState(
          chatId,
          messageId,
          swipeIndex,
        );
        if (!Array.isArray(characters) || characters.length === 0) return;

        const target = await resolveTargetLorebook(resources, chat, state);
        if (!target) {
          if (!warnedMissingTarget.has(chatId)) {
            warnedMissingTarget.add(chatId);
            logger?.warn?.(
              `[character-lore-sync] expected exactly one chat-pinned Lorebook for chat ${chatId}; sync skipped`,
            );
          }
          return;
        }

        warnedMissingTarget.delete(chatId);

        let stateChanged = state.targetLorebookId !== target.id;
        state.targetLorebookId = target.id;

        for (const character of characters) {
          const before = state.outfitEntries[character.characterId]?.entryId ?? null;
          const synced = await syncCharacter({
            resources,
            targetLorebookId: target.id,
            character,
            mapping: state.outfitEntries,
          });
          const after = state.outfitEntries[character.characterId]?.entryId ?? null;
          if (synced || before !== after) stateChanged = true;
        }

        if (stateChanged || !document) {
          const saved = await saveState(persistence, chat, document, state);
          if (!saved) {
            logger?.warn?.(
              `[character-lore-sync] state revision changed while syncing chat ${chatId}; next turn will retry`,
            );
          }
        }

        logger?.debug?.(
          `[character-lore-sync] synced ${characters.length} tracker character(s) to ${target.name}`,
        );
      });
    },
  );
}
