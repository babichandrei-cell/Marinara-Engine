Create an image-generation prompt for the final current roleplay scene.

Use the latest chronologically depicted moment consistent with all final tracker states.

Sources:

{{agent::world-state}}
= current time, broader location, weather, temperature.

{{agent::custom-tracker}}
= authoritative final environment state.

{{agent::character-tracker}}
= authoritative final character state.

Only include characters present in Character Tracker presentCharacters.

Return valid JSON only:

{
  "shouldGenerate": boolean,
  "reason": "brief explanation",
  "prompt": "image generation prompt",
  "characters": ["visible character names"]
}

Core rules:

1. Describe only the final current visible scene. Final tracker state overrides earlier narrative state.

2. Use the latest assistant response for final visible action, poses, gaze, temporary character positioning, object interaction, and composition when these do not conflict with tracker state.

3. The final prompt must be self-contained for an image model with no access to lore, trackers, character cards, prior conversation, or internal setting definitions.

4. Treat proper nouns, setting/world/faction names, genre labels, and personal style names as metadata rather than sufficient visual description. When visually relevant, express their supported meaning through concrete observable features.

5. Style may refine HOW established scene elements and garments look. Style must not create new objects, mechanisms, architecture, decorations, clothing, accessories, equipment, or characters.

6. Do not invent stereotypical genre motifs. If a concrete visual feature is not supported by tracker state or the latest narrative, omit it.

Environment:

- Scene Tracker determines Scene Style, Setting, Environment, Spatial Layout, Lighting, Atmosphere, and Visible Objects.
- Translate Scene Style into supported concrete visual characteristics such as period/cultural design language, architecture, materials, furnishings, technology appearance, and construction.
- Use Environment only for established architecture, furnishings, materials, machinery, built-in systems, and background features.
- Use Spatial Layout only for actual established positional relationships. If empty or vague, do not invent room geometry.
- Lighting is authoritative. If empty, do not invent a specific source, dramatic lighting, volumetric light, light shafts, or strong shadow patterns.
- Atmosphere is authoritative. If empty, do not invent atmospheric effects. If it establishes clear air, do not add haze, fog, smoke, steam, dust, or visible volumetric effects.
- Use Visible Objects with their established state and location. Do not invent additional narratively significant movable objects.
- Ordinary furnishings already established by Environment may appear.

Characters:

For every visible character include:
- full character's name;
- appearance;
- complete current outfit and outfit style;
- visible accessories and carried items;
- pose and action.

Character Tracker wardrobe state is authoritative.

Interpret clothing using:
1. garment item and description;
2. wardrobe.style;
3. Scene Style.

Translate supported style metadata into concrete garment characteristics such as silhouette, tailoring, construction, material, cut, proportion, closures, and surface treatment.

Preserve established garment type, coverage, length, material, color, state, and meaningful construction/style cues.

Style may refine an established garment but must not replace, redesign, modernize, normalize, or genericize it.

Preserve meaningful differences between characters' personal styles.

If a style label has no supported concrete visual meaning, preserve the established garment description rather than inventing an interpretation.

Continuity:

- Do not reconstruct earlier character presence, clothing, carried items, environment, lighting, atmosphere, or object locations.
- Do not include characters absent from final Character Tracker state.
- Do not duplicate a portable object as both carried and environmental.
- Respect established stable spatial relationships.
- Infer temporary character positions only when needed for the final depicted action.

Do not describe thoughts, dialogue, scents, sounds, invisible emotions, non-visual lore, or other non-visible information.

Create a naturalistic, visually coherent composition.

Keep the final image prompt concise while preserving all important established visual state.