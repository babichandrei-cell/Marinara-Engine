Create an image-generation prompt for the final current roleplay scene.

Use the latest chronologically depicted moment consistent with the final tracker states.

Sources:

{{agent::world-state}}
= current time, broader location, weather, temperature.

{{agent::custom-tracker}}
= final environment state.

{{agent::character-tracker}}
= final character state.

Only include characters listed in Character Tracker presentCharacters.

Return ONLY valid JSON:

{
  "shouldGenerate": boolean,
  "reason": "brief explanation",
  "prompt": "image generation prompt",
  "characters": ["visible character names"]
}

## Source priority

1. Final tracker state overrides earlier narrative state for persistent scene and character facts.
2. Use the latest assistant response for current action, pose, gaze, temporary position, object interaction, and composition when it does not conflict with tracker state.
3. Do not reconstruct an earlier state.

## General

- Describe only the final visible scene.
- The image prompt must be self-contained. The image model has no access to lore, trackers, character cards, or conversation history.
- Convert relevant setting/style information into concrete visible features.
- Proper nouns and genre/style labels are not sufficient visual descriptions by themselves.
- Do not invent unsupported architecture, objects, mechanisms, clothing, accessories, equipment, characters, lighting, or atmospheric effects.
- Style may refine the appearance of established elements but must not create or replace them.

## Environment

Use Custom Tracker as authoritative for:

- Scene Style
- Setting
- Environment
- Spatial Layout
- Lighting
- Atmosphere
- Visible Objects

Rules:

- Environment contains established architecture, furnishings, materials, machinery, built-in systems, and background features.
- Spatial Layout contains only established positional relationships. If none are established, do not invent room geometry.
- Lighting is authoritative. If empty, do not invent a specific light source or dramatic lighting.
- Atmosphere is authoritative. If empty, do not add haze, fog, smoke, steam, dust, rain, snow, or other atmospheric effects.
- Visible Objects must keep their established state and location.
- Ordinary furnishings already established by Environment may appear.

## Characters

For every visible character include:

- exactly the full character name;
- established physical appearance;
- complete current outfit;
- visible accessories or carried/held items contained in the outfit state;
- current pose and action.

Character Tracker `outfit` is authoritative for current clothing and wearable visual state.

Preserve all established outfit details that are visually relevant, including when present:

- garment type;
- color;
- material;
- cut, fit, silhouette, and length;
- coverage and meaningful exposed areas;
- open, unfastened, removed, damaged, or altered state;
- legwear;
- footwear;
- visible accessories;
- held or carried items;
- explicitly established absence of relevant clothing layers.

Do not replace detailed outfit information with generic phrases such as "steampunk outfit", "formal clothing", or "professional attire".

Do not infer missing clothing details from genre, gender, profession, status, weather, location, or personality.

Scene Style may visually refine an established garment, but must not change its garment type, color, material, length, coverage, or state.

## Continuity

- Do not include characters absent from Character Tracker.
- Do not duplicate a portable object as both carried by a character and present in the environment.
- Respect established stable spatial relationships.
- Infer temporary character position only when required by the latest visible action.
- If the latest assistant response conflicts with the final tracker state for clothing, carried items, environment, lighting, atmosphere, or object location, use the final tracker state.

## Output content

Do not include thoughts, dialogue, scents, sounds, invisible emotions, or non-visible lore in the image prompt.

Create a naturalistic, visually coherent composition.

The image MUST use cinematic realism.

Keep the image prompt concise while preserving all important established visual state.