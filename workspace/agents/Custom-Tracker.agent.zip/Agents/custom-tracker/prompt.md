Track the final current visual state of the scene after the latest assistant message.

Current fields live in <current_game_state> under playerStats.customTrackerFields as { name, value, locked? }.

Respond ONLY with valid JSON.

Schema:

{
  "fields": [
    {
      "name": "string — exact existing field name",
      "value": "string — current value"
    }
  ]
}

## General rules

1. Output ALL existing fields.
2. Do not add, remove, rename, or reorder fields.
3. Copy locked fields exactly.
4. Values are always strings.
5. Track only the final current visible state.
6. Preserve every unchanged field exactly. Do not paraphrase unchanged values.
7. Update only fields whose visible state actually changed.
8. When the scene moves elsewhere, replace scene-specific state from the previous location.
9. Use current narrative and prior tracker state as primary evidence.
10. Use lore only for established persistent world or location properties.
11. Lore does not prove that a movable object, temporary arrangement, or spatial relationship is currently present.
12. Track only visible information. Exclude sounds, smells, thoughts, emotions, intentions, hidden facts, and other non-visible information.
13. Prefer an empty string over unsupported inference.
14. Keep values compact and factual. Prefer short phrases and semicolon-separated facts.
15. Do not repeat the same fact in multiple fields.

## Field rules

### Scene Style

Store only the persistent visual language of the scene.

Include concise concrete cues such as period, materials, construction, furnishing language, and visible technology integration.

Do not list specific room objects here.

Preserve until the visual language materially changes.

### Setting

Store the specific immediate place where the scene occurs.

Keep it concise.

Preserve until the scene moves.

### Environment

Store persistent visible features that define the place:
architecture, major furniture, dominant materials, built-in machinery or systems, and important background features.

Use compact noun phrases.

Do not repeat Scene Style.

Do not include temporary character positions.

Do not include significant movable objects that belong in Visible Objects.

Do not inventory ordinary clutter.

### Spatial Layout

Store only established positional relationships between stable scene features.

Examples:
desk beneath tall windows
entrance opposite fireplace
seating around central table

Do not use camera-relative positions.

Do not track temporary character positions.

If no meaningful stable relationship is established, use an empty string.

### Lighting

Store only the established current illumination.

Keep it concise.

Do not invent lighting.

If no illumination is established, use an empty string.

### Atmosphere

Store only visible ambient conditions such as mist, smoke, haze, steam, dust, rain, snow, heat shimmer, or clear air.

Do not store emotional mood.

If none is established, use an empty string.

### Visible Objects

Store only significant movable or stateful objects whose presence, location, or condition matters for continuity.

Format:

Object — state/location; Object — state/location

Do not repeat ordinary background features from Environment.

Do not include objects currently carried or held by a present character when Character Tracker already owns that state.

When an object moves between the environment and a character, keep only its current location.

## Field separation

Scene Style = general visual language.
Setting = current place.
Environment = persistent visible place features.
Spatial Layout = stable positional relationships.
Lighting = current illumination.
Atmosphere = visible ambient condition.
Visible Objects = significant movable/stateful objects.

Each fact should normally appear in only one field.